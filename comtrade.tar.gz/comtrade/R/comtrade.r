#' UN Comtrade
#'
#' This function extracts data from the UN Comtrade database via their public API.
#'
#' @param maxrec Maximum no. of records returned (default = 50000): A valid integer in the range [1, 50000]. If the number of records returned by the query exceed max results are truncated to this number. In output types supporting metadata (e.g. json) information about the total number of records that would have been returned is included.
#' 
#' @param type Type of trade (default = C): Valid values: C Commodities (merchandise trade data), S (future) Services (trade in services data)
#' 
#' @param freq Frequency (default = A): A - Annual, M - Monthly
#' 
#' @param px Classification (default = HS): Trade data classification scheme. See list of valid classifications: HS (default) Harmonized System, H0 (HS 1992), H1 (HS 1996), H2 (HS 2002), H3 (HS 2007), H4 (HS2012), ST (SITC), S1 (SITC Revision 1), S2 (SITC Revision 2), S3 (SITC Revision 3), S4 (SITC Revision 4), BEC (Broad Economic Categories), for more see \url{http://comtrade.un.org/data/doc/api/} and \url{http://comtrade.un.org/db/mr/daReportersResults.aspx}
#' 
#' @param ps Time period (default = now): Depending on freq, time period can take either YYYY or YYYYMM or now or recent
#' 
#' @param r Reporting area: The area that reported the trade to UNSD, e.g. 0 (default), 842 (USA), see \url{http://comtrade.un.org/data/cache/reporterAreas.json}
#' 
#' @param p Partner country (default = all): partner area. The area receiving the trade, based on the reporting areas data. See list of valid partners: \url{http://comtrade.un.org/data/cache/partnerAreas.json}
#' 
#' @param rg Trade regime / trade flow (default = all): The most common area 1 (imports) and 2 (exports), see list of valid trade flows: \url{http://comtrade.un.org/data/cache/tradeRegimes.json}
#' 
#' @param cc Classification code (default = AG2): a commodity code valid in the selected classification. Full lists of codes for each classification are linked to above under the px parameter. Some codes are valid in all classifications: TOTAL Total trade between reporter and partner, no detail breakdown.; AG1, AG2, AG3, AG4, AG5, AG6 Detailed codes at a specific digit level. For instance AG6 in HS gives all of the 6-digit codes, which are the most detailed codes that are internationally comparable. Not all classifications have all digit levels available. See the classification specific codes for more information.; ALL All codes in the classification.
#' 
#' @param fmt Format (default = csv): Valid values are json or csv.
#' 
#' @return Data set in the format specified (csv or json).
#' 
#' @keywords UN Comtrade, Comtrade
#' 
#' @examples
#' # Get latest annual HS total trade data flows between US and Canada and Mexico
#'  s1 <- get.Comtrade(r = "842", p = "124,484")
#'  s1
#'  
#' get.Comtrade()

get.Comtrade <- function(url="http://comtrade.un.org/api/get?", maxrec=50000,
                         type="C", freq="A", px="HS", ps="now", r ,p = "all", rg="all", cc="TOTAL", fmt="csv")
{
  string<- paste(url, "max=", maxrec, "&", "type=", type, "&", "freq=", freq, "&", "px=", px, "&", "ps=", ps, "&", "r=", r, "&", "p=", p, "&", 
                 "rg=", rg, "&", "cc=", cc, "&", "fmt=", fmt, sep = "")
  
  # Echo HTTP call url string
  #cat(string)
  
  if(fmt == "csv") {
    raw.data <- read.csv(string, header=TRUE)
    return(list(validation=NULL, data=raw.data))
  } else {
    if(fmt == "json" ) {
      raw.data   <- fromJSON(file=string)
      data       <- raw.data$dataset
      validation <- unlist(raw.data$validation, recursive=TRUE)
      ndata      <- NULL
      if(length(data) > 0) {
        var.names <- names(data[[1]])
        data      <- as.data.frame(t( sapply(data, rbind)))
        ndata     <- NULL
        for(i in 1:ncol(data)){
          data[sapply(data[,i], is.null),i] <- NA
          ndata <- cbind(ndata, unlist(data[,i]))
        }
        ndata           <- as.data.frame(ndata)
        colnames(ndata) <- var.names
      }
      return(list(validation = validation, data = ndata))
    } else {
      stop("Invalid format paramter 'fmt'.")
    }
  }
}
